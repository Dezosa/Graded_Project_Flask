from flask import Flask, render_template, request
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import pickle
import numpy as np
import sklearn 

app = Flask(__name__)
model = pickle.load(open('loan_status_model.pkl','rb'))

'''
# MySQL database configuration
db_user = "root"
db_password = "XXX"
db_host = "localhost:3306"
db_name = "User_database_"

# Using mysql-connector-python to create a connection
mysql_conn = create_engine(f"mysql+mysqlconnector://{db_user}:{db_password}@{db_host}/{db_name}")

Base = declarative_base()

# User table class definition
class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    username = Column(String(50), nullable=False, unique=True)
    password = Column(String(100), nullable=False)

# Create the table in the database
Base.metadata.create_all(mysql_conn)

# Create a session to interact with the database
Session = sessionmaker(bind=mysql_conn)

# Route to insert a new user into the User table
@app.route('/add_user', methods=['POST'])
def add_user():
    if request.method == 'POST':
        # Retrieve form data submitted by the user
        username = request.form.get('username')
        password = request.form.get('password')

        # Create a new User object and insert it into the table
        session = Session()
        new_user = User(username=username, password=password)
        session.add(new_user)
        session.commit()
        session.close()

        return "User added successfully!"
    return "Invalid request method."
'''
def predict_loan_eligibility(user_data):
    input_features = np.array([
        user_data['gender'], user_data['married'], user_data['dependent'], user_data['education'],
        user_data['self_employment'], user_data['application_income'], user_data['coapplicant_income'],
        user_data['loan_amount'], user_data['loan_term'], user_data['credit_history'], user_data['property_area']
    ]).reshape(1, -1)

    # Use the trained model to make predictions
    prediction = model.predict(input_features)

    is_eligible = prediction[0] == 1

    return is_eligible

@app.route('/', methods=['GET'])
def home():
    return render_template('home.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        # Process the login form submission here (if needed)
        # For this example, we'll simply redirect back to the home page
        return render_template('home.html')
    return render_template('login.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        # Process the registration form submission here (if needed)
        # For this example, we'll simply redirect back to the home page
        return render_template('home.html')
    return render_template('register.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Retrieve form data submitted by the user
        gender = request.form.get('gender')
        married = request.form.get('married')
        dependent = int(request.form.get('dependent'))
        education = request.form.get('education')
        self_employment = request.form.get('self_employment')
        application_income = float(request.form.get('application_income'))
        coapplicant_income = float(request.form.get('coapplicant_income'))
        loan_amount = float(request.form.get('loan_amount'))
        loan_term = int(request.form.get('loan_term'))
        credit_history = int(request.form.get('credit_history'))
        property_area = request.form.get('property_area')

        # Prepare the user data for the loan eligibility prediction
        user_data = {
            'gender': gender,
            'married': married,
            'dependent': dependent,
            'education': education,
            'self_employment': self_employment,
            'application_income': application_income,
            'coapplicant_income': coapplicant_income,
            'loan_amount': loan_amount,
            'loan_term': loan_term,
            'credit_history': credit_history,
            'property_area': property_area
        }

        # Call the loan eligibility prediction function
        is_eligible = predict_loan_eligibility(user_data)

        # Prepare the result message to display
        result_message = "Congratulations! You are eligible for the loan." if is_eligible else "Sorry, you are not eligible for the loan."

        # Render the result template and pass the result message
        return render_template('predict.html', result_message=result_message)

if __name__ == "__main__":
    app.run()
